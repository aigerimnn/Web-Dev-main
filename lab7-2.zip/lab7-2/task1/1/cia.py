N = int(input())
n = 1
while n ** 2 <= N:
    print(n ** 2)
    n += 1