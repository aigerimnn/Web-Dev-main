N = int(input())
pow = 1
while pow <= N:
    print(pow, end=' ')
    pow *= 2