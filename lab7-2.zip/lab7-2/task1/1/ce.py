x = input()
print(int(x[::-1].lstrip("0")))
