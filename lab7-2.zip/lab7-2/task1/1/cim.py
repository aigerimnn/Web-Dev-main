N = int(input())
z = 0

for i in range(N):
    num = int(input())
    if num == 0:
        z += 1
print(z)
