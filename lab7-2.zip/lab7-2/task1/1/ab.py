number = int(input())
print("The next number for the number ", number, " is ", number + 1, ".", sep="")
print("The previous number for the number ", number, " is ", number - 1, ".", sep="")
