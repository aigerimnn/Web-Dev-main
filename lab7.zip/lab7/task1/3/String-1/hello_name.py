def hello_name(name):
    return "xyz" + name