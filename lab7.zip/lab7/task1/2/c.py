a = int(input())
b = int(input())

sum = a + b
diff = a - b
prod = a * b

print(sum, diff, prod, sep='\n')