x = input()
sum = 0

for i in x:
    sum += int(i)
print(sum)
