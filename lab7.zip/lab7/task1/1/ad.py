N = int(input())
K = int(input())
M = K % N
print(M)
