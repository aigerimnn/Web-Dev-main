total_sum = 0
for i in range(100):
    num = int(input())
    total_sum += num
print(total_sum)