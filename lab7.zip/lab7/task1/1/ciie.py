N = int(input())
pow = 1
k = 0

while pow < N:
    pow *= 2
    k += 1
print(k)
